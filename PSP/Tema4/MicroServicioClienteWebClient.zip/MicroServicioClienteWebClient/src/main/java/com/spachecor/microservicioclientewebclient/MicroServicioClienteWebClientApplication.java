package com.spachecor.microservicioclientewebclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicioClienteWebClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioClienteWebClientApplication.class, args);
	}

}
