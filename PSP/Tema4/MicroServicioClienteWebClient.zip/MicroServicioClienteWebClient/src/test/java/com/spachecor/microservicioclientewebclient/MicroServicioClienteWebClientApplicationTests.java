package com.spachecor.microservicioclientewebclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicioClienteWebClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
