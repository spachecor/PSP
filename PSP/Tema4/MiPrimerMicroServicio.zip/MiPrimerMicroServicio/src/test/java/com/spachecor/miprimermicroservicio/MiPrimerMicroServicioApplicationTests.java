package com.spachecor.miprimermicroservicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiPrimerMicroServicioApplicationTests {

    @Test
    void contextLoads() {
    }

}
