package com.spachecor.micro_contacto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroContactoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MicroContactoApplication.class, args);
    }

}
