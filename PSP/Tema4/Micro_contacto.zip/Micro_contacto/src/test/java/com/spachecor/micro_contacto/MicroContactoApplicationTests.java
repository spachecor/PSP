package com.spachecor.micro_contacto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroContactoApplicationTests {

    @Test
    void contextLoads() {
    }

}
